<?php
require_once('../config/koneksi.php');
$myArray = array();
$sql = "SELECT * FROM tb_user ORDER BY user_id ASC";
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) 
    {
        $myArray[] = $row;
    }
    mysqli_close($conn);
    echo json_encode($myArray);

}
