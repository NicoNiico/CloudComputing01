<?php
require_once('../config/koneksi.php');

if (isset($_POST['user_telp']) && isset($_POST['username']) && isset($_POST['user_email']) && isset($_POST['user_address']) && isset($_POST['models'])) {
    $user_telp              = $_POST['user_telp'];
    $username               = $_POST['username'];
    $sql = $conn->prepare("INSERT INTO tb_user (user_telp, username, user_email, user_address, models) VALUES (?, ?, ?, ?, ?)");
    $user_email             = $_POST['user_email'];
    $user_address           = $_POST['user_address'];
    $models                 = $_POST['models'];
    $sql->bind_param("sssss", $user_telp, $username, $user_email, $user_address, $models);
    $sql->execute();
    if ($sql) {
        echo json_encode(array('RESPONSE' => 'SUCCESS'));
        header("location:../readapi/tampils.php");
    } else {
        echo json_encode(array('RESPONSE' => 'FAILED'));
    }
} else {
    echo "GAGAL";
}
