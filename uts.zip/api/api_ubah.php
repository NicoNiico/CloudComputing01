<?php
require_once('../config/koneksi.php');

if (isset($_GET['user_id'])) {
    $user_telp              = $_POST['user_telp'];
    $username               = $_POST['username'];
    $user_email             = $_POST['user_email'];
    $user_address           = $_POST['user_address'];
    $models                 = $_POST['models'];
    $id = (int)$_GET['user_id'];
    $sql = $conn->prepare("UPDATE tb_user SET user_telp=?, username=?, user_email=?, user_address=?, models=? WHERE user_id=?");
    $sql->bind_param('sssssd', $user_telp, $username, $user_email, $user_address, $models, $id);
  
    if ($sql->execute()) {
        header("location:../readapi/tampils.php");
        echo json_encode(array('RESPONSE' => 'Success'));
    }
} else {
    echo "GAGAL";
    echo json_encode(array('RESPONSE' => 'FAILED'));
}
