<?php
require_once('../config/koneksi.php');

if (isset($_GET['id'])) {
    $sql = $conn->prepare("DELETE FROM tb_user WHERE user_id=?");
    $id = $_GET['id'];
    $sql->bind_param('i', $id);
    $sql->execute();
    if ($sql) {
        echo json_encode(array('RESPONSE' => 'SUCCESS'));
        header("location: http://localhost/website_xiaomi/readapi/tampils.php");
    } else {
        echo json_encode(array('RESPONSE' => 'FAILED'));
    }
} else {
    echo "GAGAL";
}
